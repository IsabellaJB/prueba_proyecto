from .CaminataAleatoria import *
from .HookeJeeves import *
from .NelderMeadSimplex import *
