from .FuncionesMultivariables import *
from .FuncionesPrueba import *
from .FuncionesUnaVariable import *