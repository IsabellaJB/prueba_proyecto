from .BasadosEnLaDerivada import *
from .EliminacionDeRegiones import *
