from .MetodoDeBiseccion import *
from .MetodoDeLaSecante import *
from .NewtonRaphson import *
